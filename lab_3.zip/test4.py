L = 'Пусть дана строка произвольной длины. Выведите информацию о том, сколько в ней символов и сколько слов.'

def count_letters(L):
    return len(L) - L.count(' ')


print(count_letters(L))
print(len(L))
print(len(L.split(' ')))
