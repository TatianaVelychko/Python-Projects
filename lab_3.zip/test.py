import string

L = 'Пусть дана строка, состоящая из слов, пробелов и знаков препинания.'
exclude = set(string.punctuation)
K = ''.join(ch for ch in L if ch not in exclude)

S = K.split()

M = ([elem for elem in S if len(elem) > 5])
print('\t'.join(M))

H = ([elem for elem in S if elem.endswith('ов')])
print('\t'.join(H))
